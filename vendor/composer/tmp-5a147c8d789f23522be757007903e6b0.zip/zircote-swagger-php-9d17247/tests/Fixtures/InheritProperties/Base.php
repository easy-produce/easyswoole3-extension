<?php

namespace OpenApi\Tests\Fixtures;

/**
 * @OA\Schema()
 */
class Base
{

    /**
     * @OA\Property();
     * @var string
     */
    public $baseProperty;
}
